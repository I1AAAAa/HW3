# README_CSS.md

## Overview
This document explains the **CSS architecture and design principles** applied throughout the Jungian Cognitive Type Test website.  
It demonstrates the structured use of modern CSS technologies, responsive design strategies, and accessibility best practices.

---

## 1. CSS Structure and Organization
All styles are consolidated in a single `style.css` file to maintain simplicity and modular organization.

### Key Sections:
1. **Global Variables and Theme**  
   - Defined color palette, spacing, and font variables using `:root`.  
   - Example:
     ```css
     :root {
       --primary-color: #004080;
       --neutral-bg: #f7f7f7;
       --accent-color: color-mix(in srgb, var(--primary-color), white 25%);
     }
     ```

2. **Typography and Layout Reset**  
   - Applied consistent base styles for text, spacing, and alignment.
   - Utilized `rem` and `em` units for scalable sizing.

3. **Page Layout with Flexbox and Grid**  
   - Flexbox used for **navigation menus**, **test question blocks**, and **buttons**.  
   - CSS Grid applied for **type description cards** to ensure symmetry.

4. **Scoped & Nested Rules**  
   - Implemented **native CSS nesting** for cleaner, modular rule sets.  
   - Ensures related selectors (like hover and label styles) stay grouped.

---

## 2. Modern CSS Features
| Feature | Description | Implementation |
|----------|--------------|----------------|
| **CSS Variables** | Theme colors and spacing consistency. | `--primary-color`, `--neutral-bg` |
| **Native CSS Nesting** | Cleaner structure without Sass. | Used in question and navigation blocks. |
| **color-mix()** | Dynamic blended color for hover states. | `color-mix(in srgb, var(--primary-color), white 25%)` |
| **Relative Units** | Scalable text and layout. | `em`, `rem`, `%` |
| **Dynamic Viewport Units** | Responsive container sizing. | `width: 90dvw; max-width: 1200px;` |
| **Transitions & Animations** | Smooth hover feedback. | Applied to buttons and cards. |

---

## 3. Responsive Design Strategy
The site implements **three key breakpoints** to accommodate mobile, tablet, and desktop displays.

### Breakpoints:
```css
@media (max-width: 480px) { /* Mobile layout */ }
@media (max-width: 768px) { /* Tablet layout */ }
@media (min-width: 1024px) { /* Desktop layout */ }
```

### Responsive Techniques:
- **Flex-direction adjustments**: Converts horizontal layouts to vertical stacks.  
- **Font resizing**: Uses `clamp()` and `rem` for scalable typography.  
- **Image scaling**: Controlled with `max-width: 100%; height: auto;`.  
- **Question blocks**: Expand fluidly without horizontal scrollbars.

---

## 4. Accessibility and Usability
Accessibility was a core design goal:
- All images include descriptive `alt` text.  
- Text contrast ratio exceeds WCAG 2.1 AA.  
- Buttons and links provide visible hover feedback.  
- Semantic HTML ensures screen reader compatibility.  

---

## 5. Performance Optimization
- Compressed `.jpg` and `.webp` formats reduce loading time.  
- Minimal use of box shadows and gradients to maintain GPU efficiency.  
- No external frameworks (e.g., Bootstrap or Tailwind).  
- CSS written with **performance-first principles** — avoiding redundancy and inline styles.

---

## 6. Example Code Snippet
```css
.question-block {
  background-color: var(--neutral-bg);
  border: 1px solid #ddd;
  border-radius: 0.8rem;
  padding: 1.5rem;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: color-mix(in srgb, var(--neutral-bg), white 20%);
  }

  label {
    font-weight: 500;
    display: inline-block;
    margin: 0.3rem 1rem;
  }
}
```

This structure demonstrates both **native nesting** and **CSS variable integration** with graceful fallback support.

---

## 7. Summary
This project’s CSS demonstrates:
- **Full compliance with Baseline 2024/2025 standards**
- **Responsive Web Design** for all devices  
- **Modern, semantic, and maintainable CSS**  
- **Accessible and consistent user experience**

✅ The styling meets the functional and aesthetic goals outlined in HW3 and showcases professional CSS practice.
